﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio7
{
    class Program
    {
        static void Main(string[] args)
        {
            int ba = 0;
            Console.WriteLine("Ingresa un numero");
            int x = int.Parse(Console.ReadLine());
            int[] a = new int[x];

            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine("Captura tu numero");
                a[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Has capturado los numeros");
            for (int j = 0; j < a.Length; j++) {
                Console.WriteLine(a[j]);
            }
            Console.WriteLine("Quieres saber la posicion de alguno?");
            int p = int.Parse(Console.ReadLine());

            for (int t=0;t<a.Length;t++) {
                if (a[t] ==p) {
                    Console.WriteLine("Se encuentra en la posicion:" +(t+1));               }

            }


            Console.ReadLine();
        }
    }
}
