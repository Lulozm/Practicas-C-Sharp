﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio8
{
    class Program
    {
        static void Main(string[] args)
        {
            int Numero;
            double Media;
            int Mediana;
           // int Mediana1 = 0;
            int Mediana2;
            double ResultadoMediana = 0;
            double Suma = 0;
            int Moda = 0;
            int Contador = 1;
            int ContadorAuxiliar = 1;

            Console.WriteLine("Introduzca el valor del arreglo:");
            Numero = int.Parse(Console.ReadLine());

            int[] Auxiliar = new int[Numero];
            int[] array = new int[Numero];


            for (int i = 0; i < Numero; i++)
            {
                Console.WriteLine("Ingresa un numero:");
                array[i] = int.Parse(Console.ReadLine());

            }

            Array.Sort(array);
            Console.WriteLine("Los numeros ordenados de menor a mayor son:");

            for (int i = 0; i < Numero; i++)
            {
                Console.WriteLine(array[i]);
                Suma = Suma + array[i];
            }

            for (int i = 0; i < array.Length; i++)
            {
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[i] == array[j])
                    {
                        Contador++;
                    }
                }
                if (Contador > ContadorAuxiliar)
                {
                    ContadorAuxiliar = Contador;
                    Moda = array[i];
                }
                Contador = 1;
            }

            Media = Suma / Numero;
            Console.WriteLine("La media es:" + Media);

            Console.WriteLine("La moda es:" + Moda);


            if (Numero % 2 == 0)
            {
                Mediana = (Numero + 1) / 2;
                Mediana2 = (Numero / 2) - 1;
                ResultadoMediana = (array[Mediana] + array[Mediana2]);
                double ResultadoMediana2 = (ResultadoMediana / 2);
                Console.WriteLine("La mediana es:" + ResultadoMediana2);
            }
            else
            {
                Mediana = (Numero + 1) / 2;
                Console.WriteLine("La mediana esta en la posicion:" + Mediana);
            }
            Console.ReadKey();
        }
    }
}
