﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Captura 1 si quieres calcular el perimetro de un triangulo, 2 el perimetro de un triangulo equilatero, 3 el perimetro de un cuadrado, 4 el perimetro de un rombo, 5 el perimetro de un circulo");
            int n = int.Parse(Console.ReadLine());
            switch (n)
            {
                case 1:
            
           
            area2 obj = new area2(); //perimetro del  triangulo
            Console.WriteLine("Captura la altura de tu triangulo");
            double x = double.Parse(Console.ReadLine());
            obj.x = x;

            Console.WriteLine("Captura la base de tu triangulo");
            double y = double.Parse(Console.ReadLine());
            obj.y = y;

            obj.AREAr();
            Console.WriteLine("Perimetro del triangulo: " + obj.AREAr());
            Console.ReadLine();
                    break;


                case 2:
            area2 obj1 = new area2();  //perimetro del  triangulo EQUILATERO
            Console.WriteLine("Captura el lado de tu triangulo");
            x = double.Parse(Console.ReadLine());
            obj1.x = x;
            
            obj1.equi();
            Console.WriteLine("Perimetro del triangulo equilatero"+ obj1.equi());
            Console.ReadLine();

                    break;


                case 3:
            area2 obj2 = new area2(); //Perimetro del cuadrado
            Console.WriteLine("Captura el lado de tu cuadrado");
            x = double.Parse(Console.ReadLine());
            obj2.x = x;
            obj2.cuadrado();
            Console.WriteLine("Perimetro del cuadrado"+ obj2.cuadrado());
            Console.ReadLine();
                    break;

                //Perimetro del rombo

                case 4:
            area2 obj3 = new area2();
            Console.WriteLine("Captura la base de tu rombo");
             x = double.Parse(Console.ReadLine());
            obj3.x = x;
            Console.WriteLine("Captura la altura de tu rombo");
            y = double.Parse(Console.ReadLine());
            obj3.y = y;
            obj3.rombo();
            Console.WriteLine("Perimetro del rombo: " + obj3.rombo());
            Console.ReadLine();

                    break;

                //Perimetro del circulo

                case 5:
            area2 obj4 = new area2();
            Console.WriteLine("Captura el radio de tu circulo");
            x = double.Parse(Console.ReadLine());
            obj4.x = x;
            obj4.circulo();
            Console.WriteLine("Perimetro del circulo:" + obj4.circulo());
            Console.ReadLine();
                    break;
        }
    }
}
}