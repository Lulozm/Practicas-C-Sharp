﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio2 { 
    class area2
    {

        public double  x, y;

        public double AREAr() //perimetro triangulo normal
        {
            double r = (this.x * 2) + this.y;
            return r;

        }

        public double equi() //perimetro triangulo equilatero
        {
            double eq = this.x * 3;
            return eq;
        }

  public double cuadrado()//perimetro cuadrado
        {
     double c = this.x * 4;
            return c;
        }

        public double rombo() //perimetro rombo
        {
            double ro = (this.x * 2) + (this.y * 2);
            return ro;

        }
        public double circulo() //perimetro circulo
        {
            double ro = 2 * (this.x * 3.1416);
            return ro;
        }
    }
}
