﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio9
{
    class Program
    {
        static void Main(string[] args)
        {
            double promedio = 0;
            string[] alumno = new string[3];
            double[] calificacion = new double[3];
            int[] matriculas = new int[3];
            for (int i = 0; i < alumno.Length; i++)
            {
                Console.WriteLine("Captura el nombre de tu alumno");
                alumno[i] = Console.ReadLine();
                Console.WriteLine("Captura la  calificacion del alumno");
                int cal1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Captura la  calificacion  2 del alumno");
                int cal2 = int.Parse(Console.ReadLine());
                Console.WriteLine("Captura la  calificacion  3 del alumno");
                int cal3 = int.Parse(Console.ReadLine());

               promedio = (cal1 + cal2 + cal3) / 3;
                calificacion[i] = promedio;

            }
            Console.WriteLine("El alumno: " + alumno[0] + "  Con el promedio:" + calificacion[0]);
            if (calificacion[0] >= 8)
                {
                    Console.WriteLine("Esta aprobado");
                    

                }
                else
                    Console.WriteLine("Esta reprobado");

            Console.WriteLine("El alumno: " + alumno[1] + "  Cuenta con el promedio final de:" + calificacion[1]);
            if (calificacion[1] >= 8)
            {
                Console.WriteLine("Esta aprobado");


            }
            else
                Console.WriteLine("Esta reprobado");

            Console.WriteLine("El alumno: " + alumno[2] + "  Con el promedio:" + calificacion[2]);
            if (calificacion[2] >= 8)
            {
                Console.WriteLine("Esta aprobado");


            }
            else
                Console.WriteLine("Esta reprobado");


            Console.ReadLine();
        }
    }
}
