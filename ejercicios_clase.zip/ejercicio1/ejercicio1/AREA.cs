﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio1
{
    public class AREA
    {
        public int b, h;
        public double ra, d, D;
        public double AREAr()
        {
      double r = (this.b * this.h)/2;
            return r;          
         }
        public double equi()
        {
            double eq = (Math.Sqrt(3) / 4) * Math.Pow(this.b, 2);
            return eq;
        }
        public int cuadrado()
        {
            int c = this.b * this.b;
            return c;
        }
        public double rombo()
        {
            double ro = this.d * (this.D / 2);
            return ro;
       
        }
        public double circulo()
        {
      double ro = Math.Pow(this.ra,2) * 3.1416;
            return ro;
        }
    }
}