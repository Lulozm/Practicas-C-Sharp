﻿using System;   
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio1  
{
    
       
    class Program
    {
        public  static void Main(string[] args)
            {
                AREA obj = new AREA();
                obj.b = 5;
                obj.h = 10;
                obj.AREAr();
                Console.WriteLine("Area" + obj.AREAr());
                Console.ReadLine();

            
            AREA obj1 = new AREA();
            obj1.b = 10;
            obj1.equi();
            Console.WriteLine("Area del triangulo equilatero:" + obj1.equi());
            Console.ReadLine();

            AREA obj2 = new AREA();
            obj2.b = 20;
            obj2.cuadrado();
            Console.WriteLine("Area del cuadrado:" + obj2.cuadrado());
            Console.ReadLine();

            AREA obj3 = new AREA();
            obj3.D= 30;
            obj3.d = 10;
            obj3.rombo();
            Console.WriteLine("Area del rombo:" + obj3.rombo());
            Console.ReadLine();

            AREA obj4 = new AREA();
            obj4.ra = 10;
            obj4.circulo();
            Console.WriteLine("Area del circulo:" + obj4.circulo());
            Console.ReadLine();



        }
        }
    }

