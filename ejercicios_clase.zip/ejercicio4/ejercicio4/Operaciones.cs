﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio4
{
    class Operaciones
    {
       
        public double suma(double x, double y)
        {
            double res = x + y;
            return res;
        }

        public double resta(double x, double y)
        {
            double res = x - y;
            return res;
        }

        public double multiplicacion(double x, double y)
        {
            double res = x * y;
            return res;
        }

        public double division(double x, double y)
        {
            double res = x / y;
            return res;
        }

        public double potencia(double x, double y)
        {
            double res = Math.Pow(x, y);
            return res;
        }

        public double raiz(double x)
        {
            double res = Math.Sqrt(x);
           
            return res;
            
        }
    }
}
