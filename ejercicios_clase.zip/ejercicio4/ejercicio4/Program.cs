﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Teclea la operación que deseas realizar: \n 1-Suma \n 2-Resta \n 3-Multiplicación \n 4-División \n 5-Potencia \n 6-Raíz cuadrada");
            int n = int.Parse(Console.ReadLine());

            Operaciones obj = new Operaciones();
            switch (n){
            case 1:
            //suma
            Console.WriteLine("Captura tu primer numero");
            double x = double.Parse(Console.ReadLine());
           

            Console.WriteLine("Captura tu segundo numero");
            double y = double.Parse(Console.ReadLine());
          
            
            Console.WriteLine("El resultado de la suma: " + obj.suma(x,y));
            Console.ReadLine();
                    break;

            case 2:
             //resta
            Console.WriteLine("Captura tu primer numero");
             x = double.Parse(Console.ReadLine());
            

            Console.WriteLine("Captura tu segundo numero");
             y = double.Parse(Console.ReadLine());
           

       
            Console.WriteLine("El resultado de la resta: " + obj.resta(x,y));
            Console.ReadLine();
                    break;
             
             case 3:
             //multiplicacion
            Console.WriteLine("Captura tu primer numero");
            x = double.Parse(Console.ReadLine());
           

            Console.WriteLine("Captura tu segundo numero");
             y = double.Parse(Console.ReadLine());
           

            
            Console.WriteLine("El resultado de la multiplicacion: " + obj.multiplicacion(x,y));
            Console.ReadLine();
                    break;
             
              case 4: 
           //división
            Console.WriteLine("Captura tu primer numero");
            x = double.Parse(Console.ReadLine());
            

            Console.WriteLine("Captura tu segundo numero");
             y = double.Parse(Console.ReadLine());
           

           
            Console.WriteLine("El resultado de la division: " + obj.division(x,y));
            Console.ReadLine();
                    break;

             case 5: 
            //potencia
            Console.WriteLine("Captura tu primer numero");
             x = double.Parse(Console.ReadLine());
            
            Console.WriteLine("Captura tu segundo numero");
             y = double.Parse(Console.ReadLine());
          
            Console.WriteLine("El resultado de la potencia: " + obj.potencia(x,y));
            Console.ReadLine();
                    break;
            
              case 6: 
            //raiz
            Console.WriteLine("Captura tu primer numero");
            x = double.Parse(Console.ReadLine());
         
            Console.WriteLine("El resultado de la raiz: " + obj.raiz(x));
            Console.ReadLine();
                    break;





}
           
        }
    }
}
