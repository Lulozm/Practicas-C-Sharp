﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[2];

            Console.WriteLine("Captura tu numero 1 a evaluar");
            a[0] = int.Parse(Console.ReadLine());
            Console.WriteLine("Captura tu numero 2 a evaluar");
            a[1] = int.Parse(Console.ReadLine());

            if (a[0] % 2 == 0 && a[1] % 2 == 0)
            {
                int suma = a[0] + a[1];
                Console.WriteLine("Los numeros son pares");
                Console.WriteLine("Los numeros que ingresaste son: " + a[0] + " y  "+ a[1]);
                Console.WriteLine("La suma de los  numeros es:" + suma);
            }
            else
                Console.WriteLine("Los numeros son impares");

            Console.ReadLine();
        }
    }
}
