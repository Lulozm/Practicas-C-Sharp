﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio12
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] multi1 = new int[3, 3];
            int[,] multi2 = { { 1, 2, 3 }, { 4, 5, 6 } };
            int[,] multi3 = { { 4, 7, 6 }, { 5, 4, 2 }, { 1, 2, 3 } };

            for (int i = 0; i < multi2.GetLength(1); i++)
            {
                for (int j = 0; j < multi3.GetLength(1); j++)
                {
                    multi1[0, 0] = (multi3[0, 0] * multi2[0, 0]) + (multi3[1, 0] * multi2[0, 1]) + (multi3[2, 0] * multi2[0, 2]);
                    multi1[0, 1] = (multi3[0, 1] * multi2[0, 0]) + (multi3[1, 1] * multi2[0, 1]) + (multi3[2, 1] * multi2[0, 2]);
                    multi1[0, 2] = (multi3[0, 2] * multi2[0, 0]) + (multi3[1, 2] * multi2[0, 1]) + (multi3[2, 2] * multi2[0, 2]);
                    multi1[1, 0] = (multi3[0, 0] * multi2[1, 0]) + (multi3[1, 0] * multi2[1, 1]) + (multi3[2, 0] * multi2[1, 2]);
                    multi1[1, 1] = (multi3[0, 1] * multi2[1, 0]) + (multi3[1, 1] * multi2[1, 1]) + (multi3[2, 1] * multi2[1, 2]);
                    multi1[1, 2] = (multi3[0, 2] * multi2[1, 0]) + (multi3[1, 2] * multi2[1, 1]) + (multi3[2, 2] * multi2[1, 2]);
                    Console.WriteLine(multi1[i, j] + "-");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}