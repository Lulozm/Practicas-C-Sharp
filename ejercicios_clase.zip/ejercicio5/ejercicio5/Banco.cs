﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio5
{
   public class Banco
    {

        public double deposito(double saldo,double x)
        {
            saldo = 5286.24;
          double  depos = saldo + x;
            return depos;
        }

        public int retiro (int saldo2, int x2)
        {
            saldo2 = 5286;
           int ret = saldo2 - x2;
            return ret;
        }


       public DateTime getFechaActual()
        {
            int anio, dia, mes;
            DateTime dtFecha;
            anio = DateTime.Today.Year;
            mes = DateTime.Today.Month;
            dia = DateTime.Today.Day;
            dtFecha = new DateTime(anio, mes, dia);
            return dtFecha;
        }
       

    }
}
