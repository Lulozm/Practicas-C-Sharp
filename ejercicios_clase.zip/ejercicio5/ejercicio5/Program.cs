﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido a Banco bonito ingrese su cuenta bancaria (8 Dígitos)");
            int cuenta = int.Parse(Console.ReadLine());
            Console.WriteLine("ingrese su NIP (4 Dígitos)");
            int NIP = int.Parse(Console.ReadLine());

            Console.WriteLine("¿Qué operación deseas realizar?  \n 1-Déposito a cuentas  \n 2-Retiro   \n 3-Saldo actual");
            int opera = int.Parse(Console.ReadLine());

            Banco obj = new Banco();

            switch (opera)
            {
                case 1:
                    //deposito
                   
                    Console.WriteLine("Ingresa el monto a depositar a tu cuenta");
                    double x = double.Parse(Console.ReadLine());
                    double saldo = 5286.24;
               
                    Console.WriteLine("Espera mientras realizamos la operación");
                    Console.WriteLine(".......................................");
                    Console.WriteLine("Operación exitosa");
                    Console.WriteLine("Tu saldo anterior es: " + saldo);
                    Console.WriteLine("Tu saldo actual es: "+ obj.deposito(saldo,x));
                    Console.WriteLine("Sucursal #8214 \nFecha de la transacción: " + DateTime.Now.ToString("G"));
                    break;

                
                case 2:
                    //retiro

                    Console.WriteLine("Ingresa el monto que deseas retirar de tu cuenta");
                   int x2 = int.Parse(Console.ReadLine());
                     int saldo2 = 5286;
                    Console.WriteLine("Espera mientras realizamos la operación");
                    Console.WriteLine(".......................................");
                    Console.WriteLine("Operación exitosa");
                    Console.WriteLine("Tu saldo anterior es: " + saldo2);
                    Console.WriteLine("Tu saldo actual es: " + obj.retiro(saldo2, x2));
                    Console.WriteLine("Sucursal #8214 \nFecha de la transacción: " + obj.getFechaActual());
                    break;

                case 3:
                    //saldo
                    int saldo3 = 5286;
                    Console.WriteLine("Tu saldo actual es: " + saldo3);
                    Console.WriteLine("Sucursal #8214 \nFecha de la transacción: " + obj.getFechaActual());
                    break;
            }


            Console.ReadLine();
        }
    }
}
