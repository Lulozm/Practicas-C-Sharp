﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace palindromo
{
    class palindromo
    {
        static void Main(string[] args)
        {
            


            string pal1 = "", pal2 = "";
            string le = "";
            int i = 0, cont = 0;
            Console.Write("Ingrese una palabra: ");
            pal1 = Console.ReadLine();
            cont = pal1.Length;
            for (i = cont - 1; i >= 0; i--)
            {
                le = pal1.Substring(i, 1);
                pal2 = pal2 + le;
            }

            Console.Write("\nPalabra invertida  : " + pal2);
            if (pal1.Equals(pal2))
            {
                Console.WriteLine("\nComo al invertirlas son iguales  es un palindromo");
            }
            else
            {
                Console.WriteLine("\nNo es palindromo");
            }

            Console.ReadKey();

        }
    }
}