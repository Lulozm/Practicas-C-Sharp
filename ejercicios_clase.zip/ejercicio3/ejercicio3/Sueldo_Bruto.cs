﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3
{
   public class Sueldo_Bruto { 
   public double sphora;
    public double htrabajada;
    public double s;
    public double punt;
    public double prod;
    public double ahorr;
    public double seg;
    public double ims;
    public double sbruto;
    //sueldo 
    public double total()
    {
        s = this.sphora * this.htrabajada;
        return s;
    }
    //puntualidad
    public double pun()
    {
        punt = s * 0.02;
        return punt;
    }
    //productividad
    public double pro()
    {
        prod = s * 0.05;
        return prod;
    }
    //Fondo de Ahorro
    public double fondo()
    {
        ahorr = s * 0.035;
        return ahorr;
    }
    //IMMS
    public double seguro()
    {
        seg = s * 0.025;
        return seg;
    }
    //infonavit 
    public double info()
    {
        ims = s * 0.0175;
        return ims;
    }

    //sbruto

    public double gtotal()
    {
        sbruto = (s + punt + prod) - (ahorr + seg + ims);
        return sbruto;
    }
}
    }
