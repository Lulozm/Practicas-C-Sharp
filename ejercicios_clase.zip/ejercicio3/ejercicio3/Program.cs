﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            Sueldo_Bruto obj = new Sueldo_Bruto();

            Console.WriteLine("Ingresa el Nombre del Trabajador");
            string nombre = Console.ReadLine();
            Console.WriteLine("Ingresa el Departamento");
            string dpto = Console.ReadLine();
            Console.WriteLine("Ingresa Pago por Hora");
            obj.sphora = float.Parse(Console.ReadLine());
            Console.WriteLine("Ingresa Horas Trabajadas");
            obj.htrabajada = float.Parse(Console.ReadLine());
            Console.WriteLine("                             ");
            Console.WriteLine("                             ");
            Console.WriteLine("                             ");
            Console.WriteLine("Nombre del Trabajador          " + nombre);
            Console.WriteLine("Departamento                   " + dpto);
            Console.WriteLine("Sueldo                         " + obj.total());
            Console.WriteLine("Bono de Puntualidad            + " + obj.pun());
            Console.WriteLine("Bono de Productividad          + " + obj.pro());
            Console.WriteLine("Fondo de Ahorro                - " + obj.fondo());
            Console.WriteLine("Seguro Social                  - " + obj.seguro());
            Console.WriteLine("Infonavit                      - " + obj.info());
            Console.WriteLine("Sueldo Neto                    = " + obj.gtotal());

            Console.ReadKey();
        }
    }
}
