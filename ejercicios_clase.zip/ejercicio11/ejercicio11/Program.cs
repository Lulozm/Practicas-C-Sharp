﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio11
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] Mult = new int[3, 3];

            int[,] Multi = { { 1, 2, 3 }, { 4, 5, 6 } };

            int[,] Multi2 = { { 4, 7, 6 }, { 5, 4, 2 } };


            for (int i = 0; i < Multi.GetLength(0); i++)
            {
                for (int j = 0; j < Multi.GetLength(1); j++)
                {
                    Mult[i, j] = (Multi[i, j] + Multi2[i, j]);
                    Console.Write(Mult[i, j]);
                }

                Console.WriteLine("");
            }
            Console.ReadKey();


            for (int i = 0; i < Multi.GetLength(0); i++)
            {
                for (int j = 0; j < Multi.GetLength(1); j++)
                {
                    Mult[i, j] = (Multi[i, j] + Multi2[i, j]);

                    if (Mult[i, j] % 3 == 0)
                    {
                        Console.WriteLine("Los multiplos de 3 son:" + Mult[i, j]);
                    }
                }
                Console.WriteLine("");
            }
            Console.ReadKey();
        }
    }
}
